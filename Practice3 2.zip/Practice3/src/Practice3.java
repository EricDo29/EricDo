// Eric Do
// CS2050 (2pm)
//Due: 02/27/24
public class Practice3
{
    public static void main(String[] args){

        double time;
        int[] n = {5, 10, 20, 25};
        long ans;
        try{
            System.out.println("Recursive Factorial");

            for (int i = 0 ; i < n.length ; i++)
            {
                time = System.nanoTime();
                ans = recursiveFactorial(n[i]);
                time = System.nanoTime() - time;
                printResults(n[i], ans, time);
            }
            System.out.println();

            System.out.println("Iterative Factorial");

            for (int i = 0 ; i < n.length ; i++)
            {
                time = System.nanoTime();
                ans = iterativeFactorial(n[i]);
                time = System.nanoTime() - time;
                printResults(n[i], ans, time);
            }
            System.out.println();
        }
        catch (IllegalArgumentException e){
            System.out.println("Cannot input a negative number");
            e.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }


    static long recursiveFactorial(int n) throws IllegalArgumentException{
        if (n < 0)
            throw new IllegalArgumentException();
        else if (n == 0)
            return 1;
        return n * recursiveFactorial(n - 1);
    }
    static long iterativeFactorial(int n) throws IllegalArgumentException{
        long ans = 1;
        if (n < 0)
            throw new IllegalArgumentException();
        for (int i = 1 ; i <= n ; i++){//for loop for iterativeFactorial
            ans *= i;
        }
        return ans;
    }

    static void printResults(int n, long ans, double time){
        final double TO_SEC = 1_000_000_000;
        System.out.println("n = " + n + "\t\tanswer = " + ans + "\t\ttime = " + (time/TO_SEC) + " seconds");
    }
}