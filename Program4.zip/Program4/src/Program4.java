//Eric Do
//CS2050 (2pm)
//Due: 02/20/24
import java.io.*;
import java.util.*;

public class Program4 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine().trim();
        try {
            int[] arr;
            double time;
            FileWriter writer;

            arr = scan(fileName);
            time = System.nanoTime();
            bubbleSort(arr);
            time = (System.nanoTime() - time) / 1e9;
            writer = new FileWriter("Program4.out");
            writer.write("Bubble sort\nitems: " + arr.length + "\ttime: " + String.format("%.2f", time) + " seconds\n\n");
            writer.close();

            arr = scan(fileName);
            time = System.nanoTime();
            selectionSort(arr);
            time = (System.nanoTime() - time) / 1e9;
            writer = new FileWriter("Program4.out", true);
            writer.write("Selection sort\nitems: " + arr.length + "\ttime: " + String.format("%.2f", time) + " seconds\n\n");
            writer.close();

            arr = scan(fileName);
            time = System.nanoTime();
            insertionSort(arr);
            time = (System.nanoTime() - time) / 1e9;
            writer = new FileWriter("Program4.out", true);
            writer.write("Insertion sort\nitems: " + arr.length + "\ttime: " + String.format("%.2f", time) + " seconds\n\n");
            writer.close();

            ArrayList<Integer> arrList = new ArrayList<>();
            arr = scan(fileName);
            arrList.addAll(Arrays.asList(Arrays.stream(arr).boxed().toArray(Integer[]::new)));
            time = System.nanoTime();
            Collections.sort(arrList);
            time = (System.nanoTime() - time) / 1e9;
            writer = new FileWriter("Program4.out", true);
            writer.write("System sort\nitems: " + arrList.size() + "\ttime: " + String.format("%.2f", time) + " seconds\n\n");
            writer.close();

            System.out.println("Done!");
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            System.out.println("IO exception");
        } catch (Exception e) {
            System.out.println("An error occurred");
            e.printStackTrace();
        }
    }

    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                int temp = arr[i];
                arr[i] = arr[minIndex];
                arr[minIndex] = temp;
            }
        }
    }

    public static void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; ++i) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }

    public static int[] scan(String filename) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filename));
        ArrayList<Integer> list = new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) {
            list.add(Integer.parseInt(line));
        }
        br.close();
        int[] arr = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            arr[i] = list.get(i);
        }
        return arr;
    }
}


