public class Geometry
{
    //variables
    int radius;
    int height;
    double circumference;
    double area;
    double volume;

    //Geometry constructors
    public Geometry(int radius, int height)
    {
        this.radius = radius;
        this.height = height;
    }
    public Geometry(int radius)
    {
        this(radius, 0);
    }
    public Geometry()
    {
        this(0, 0);
    }

    //get methods
    int getRadius(){
        return radius;
    }
    int getHeight(){
        return height;
    }
    double getCircumference(){
        return circumference;
    }
    double getArea(){
        return area;
    }
    double getVolume(){
        return volume;
    }
    //set methods
    public void setRadius(int radius){
        this.radius = radius;
    }
    public void setHeight(int height){
        this.height = height;
    }
    public void setCircumference(double circumference){
        this.circumference = circumference;
    }
    public void setArea(double area){
        this.area = area;
    }
    public void setVolume(double volume){
        this.volume = volume;
    }

    //calculation methods
    public double calculateCirc()
    {
        return ((double) (2 * Math.PI * radius));
    }
    public double calculateArea()
    {
        return ((double) (Math.PI * Math.pow(radius, 2)));
    }
    public double calculateVolume()
    {
        return ((double) (area * height));
    }
}
