//Eric Do
// Due Date 02/06/2024
// CS2050 (
//Eric Do
//Due Date 02/09/24
//CS2050 (2pm)
import java.io.*;
import java.util.*;

public class Program2 {


    static final String HEADER_FMT = "%-20s%-20s%-20s%-20s%-20s";
    static final String OUT_FMT = "%-20s%-20s%-20.4f%-20.4f%-20.4f";

    public static String input() {
        Scanner stdIn = new Scanner(System.in);
        return stdIn.nextLine();
    }

    public static int lineCount(File f) {
        try (LineNumberReader fr = new LineNumberReader(new FileReader(f))) {
            fr.skip(Long.MAX_VALUE);
            return fr.getLineNumber();
        } catch (IOException e) {
            return -1;
        }
    }

    public static void main(String[] args) {
        Scanner read;
        BufferedWriter out;

        File file;
        int size;
        String[] in;
        Geometry[] shapes;

        try {
            System.out.print("Enter a file name: ");
            file = new File(input());

            size = lineCount(file);
            read = new Scanner(new BufferedReader(new FileReader(file)));

            shapes = new Geometry[size];
            for (int i = 0; i < size; i++) {
                shapes[i] = new Geometry();
                try {
                    in = read.nextLine().replaceAll(" +", " ").split(" ");
                    shapes[i].setRadius((int) Double.parseDouble(in[0].trim()));
                    if (in.length >= 2)
                        shapes[i].setHeight((int) Double.parseDouble(in[1].trim()));
                    shapes[i].setCircumference(shapes[i].calculateCirc());
                    shapes[i].setArea(shapes[i].calculateArea());
                    shapes[i].setVolume(shapes[i].calculateVolume());
                } catch (NoSuchElementException | IndexOutOfBoundsException | NumberFormatException ignored) {
                    shapes[i] = new Geometry();
                }
            }
            read.close();

            out = new BufferedWriter(new FileWriter("Program2.out"));
            out.write(String.format(HEADER_FMT, "radius", "height", "circumference", "area", "volume"));
            out.newLine();
            for (Geometry shape : shapes) {
                if (shape.getRadius() != 0) {
                    out.write(String.format(OUT_FMT, shape.getRadius(), shape.getHeight(),
                            shape.getCircumference(), shape.getArea(), shape.getVolume()));
                    out.newLine();
                }
            }
            out.close();
            System.out.println("Done! Check Program2.out for the results.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Please ensure the file path is correct.");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("An unexpected error occurred.");
            e.printStackTrace();
        }
    }
}